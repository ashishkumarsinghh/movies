import React from "react";

const Header = () => {
  return (
    <div className="masthead">
      <h2>Ashmovies</h2>
    </div>
  );
};
export default Header;
